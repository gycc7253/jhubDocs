from dummyauthenticator.dummyauthenticator import DummyAuthenticator

__all__ = [DummyAuthenticator]
